<!--  / right container \ -->
<div id="rightCntr">

	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('default_sidebar') ) : ?><?php endif; ?>

</div>
<!--  \ right container / -->

