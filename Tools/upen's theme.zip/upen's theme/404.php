<?php get_header(); ?>

<!--  / left side \ -->
<div id="leftSide">

    <h2 class="center">Error 404 - Not Found</h2>

</div>
<!--  \ left side / -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>