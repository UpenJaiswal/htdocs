<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/calltoaction/call-to-action.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/calltoaction/custom-styles/call-to-action.php';