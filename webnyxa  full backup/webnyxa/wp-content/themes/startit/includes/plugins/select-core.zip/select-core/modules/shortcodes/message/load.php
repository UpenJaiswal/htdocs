<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/message/message.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/message/custom-styles/message.php';