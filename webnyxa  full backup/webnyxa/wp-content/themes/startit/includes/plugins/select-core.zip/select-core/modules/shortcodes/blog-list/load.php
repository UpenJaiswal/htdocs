<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/blog-list/blog-list.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/blog-list/custom-styles/blog-list.php';