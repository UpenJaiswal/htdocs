<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/service-table/service-table.php';