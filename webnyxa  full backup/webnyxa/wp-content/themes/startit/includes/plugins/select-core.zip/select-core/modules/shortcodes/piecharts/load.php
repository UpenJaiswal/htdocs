<?php

//Pie Chart Basic
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartbasic/load.php';

//Pie Chart Basic
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartwithicon/load.php';

//Pie Chart Pie
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartpie/load.php';

//Pie Chart Doughnut
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/piecharts/piechartdoughnut/load.php';