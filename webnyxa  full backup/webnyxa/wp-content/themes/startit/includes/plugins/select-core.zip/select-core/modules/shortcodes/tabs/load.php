<?php
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/tabs/tabs.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/tabs/tab.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/tabs/options-map/map.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/tabs/custom-styles/custom-styles.php';
