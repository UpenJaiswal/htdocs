<?php
/**
 * 3d mobile showcase item template
 */
?>


<div class="qodef-screen" <?php echo startit_qode_get_inline_style($mobile_showcase_item_image); ?>>
     <div class="qodef-label"><?php echo esc_attr($text)?></div>
</div>

