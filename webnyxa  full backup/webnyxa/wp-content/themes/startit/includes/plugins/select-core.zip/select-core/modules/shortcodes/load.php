<?php

require_once QODE_CORE_ABS_PATH . '/modules/shortcodes/shortcode-helpers.php';

do_action('qode_core_shortcodes_load');

require_once QODE_CORE_ABS_PATH . '/modules/shortcodes/shortcode-loader.php';