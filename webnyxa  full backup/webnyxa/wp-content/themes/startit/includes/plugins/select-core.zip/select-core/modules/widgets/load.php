<?php


require_once QODE_CORE_ABS_PATH . '/modules/widgets/widget-helpers.php';

do_action('qode_core_widgets_load');